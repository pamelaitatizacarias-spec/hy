// Historias desplegables
    document.querySelectorAll(".story-toggle").forEach(button => {
      button.addEventListener("click", () => {
        const detail = button.nextElementSibling;
        const open = detail.classList.toggle("open");
        button.setAttribute("aria-expanded", String(open));
        button.textContent = open ? "Ocultar el final ↑" : "Leer el final →";
      });
    });

    // Curiosidades
    const facts = [
      { title: "¿De dónde viene Halloween?", text: "Sus raíces se relacionan con Samhain, una antigua festividad celta que marcaba el final de la cosecha y el comienzo de la parte más oscura del año.", emoji: "🎃" },
      { title: "¿Por qué usamos calabazas?", text: "Las calabazas talladas se hicieron populares en Norteamérica. Antes, en algunas regiones de Europa se utilizaban nabos para crear faroles.", emoji: "🕯️" },
      { title: "¿Qué significa «trick or treat»?", text: "La expresión se traduce habitualmente como «truco o trato». Los chicos recorren las casas disfrazados y suelen recibir golosinas.", emoji: "🍬" },
      { title: "¿Halloween se celebra en todos lados igual?", text: "No. Las costumbres varían según el país y la comunidad; en algunos lugares se organizan fiestas, mientras que en otros tiene menos presencia.", emoji: "🌎" },
      { title: "¿Por qué se usan disfraces?", text: "Los disfraces forman parte de antiguas costumbres y, hoy, son una manera de jugar con personajes fantásticos, monstruos y criaturas misteriosas.", emoji: "🧛" }
    ];
    let factIndex = 0;
    function showFact(index) {
      factIndex = (index + facts.length) % facts.length;
      const fact = facts[factIndex];
      document.getElementById("factCount").textContent = `Dato ${String(factIndex + 1).padStart(2, "0")}`;
      document.getElementById("factTitle").textContent = fact.title;
      document.getElementById("factText").textContent = fact.text;
      document.getElementById("factEmoji").textContent = fact.emoji;
    }
    document.getElementById("nextFact").addEventListener("click", () => showFact(factIndex + 1));
    document.getElementById("randomFact").addEventListener("click", () => {
      let next; do { next = Math.floor(Math.random() * facts.length); } while (next === factIndex);
      showFact(next);
    });

    // Juego de preguntas
    const questions = [
      { q: "¿Qué día se celebra Halloween tradicionalmente?", a: ["31 de octubre", "1 de enero", "25 de diciembre"], correct: 0, explain: "¡Correcto! Halloween se celebra tradicionalmente el 31 de octubre." },
      { q: "¿Qué verdura se asocia especialmente con Halloween?", a: ["Pepino", "Calabaza", "Lechuga"], correct: 1, explain: "¡Muy bien! La calabaza tallada es uno de sus símbolos más conocidos." },
      { q: "¿Cómo se llama la actividad de pedir golosinas casa por casa?", a: ["Truco o trato", "Búsqueda del tesoro", "Carrera de monstruos"], correct: 0, explain: "¡Exacto! Es la tradición conocida como «truco o trato»." },
      { q: "¿Cuál de estos personajes aparece mucho en la decoración de Halloween?", a: ["Un pingüino", "Un fantasma", "Un delfín"], correct: 1, explain: "¡Correcto! Los fantasmas son figuras clásicas de Halloween." }
    ];
    let questionIndex = 0, score = 0, answered = false;
    const questionEl = document.getElementById("quizQuestion");
    const answersEl = document.getElementById("answers");
    const feedbackEl = document.getElementById("quizFeedback");
    const nextQuestionBtn = document.getElementById("nextQuestion");
    function renderQuestion() {
      answered = false;
      const item = questions[questionIndex];
      document.getElementById("questionCount").textContent = `Pregunta ${questionIndex + 1} de ${questions.length}`;
      document.getElementById("progressBar").style.width = `${questionIndex / questions.length * 100}%`;
      questionEl.textContent = item.q;
      answersEl.innerHTML = "";
      feedbackEl.textContent = "";
      nextQuestionBtn.disabled = true;
      nextQuestionBtn.textContent = questionIndex === questions.length - 1 ? "Ver resultado →" : "Siguiente →";
      item.a.forEach((answer, index) => {
        const button = document.createElement("button");
        button.className = "answer"; button.type = "button"; button.textContent = answer;
        button.addEventListener("click", () => chooseAnswer(index, button));
        answersEl.appendChild(button);
      });
    }
    function chooseAnswer(index, selectedButton) {
      if (answered) return;
      answered = true;
      const item = questions[questionIndex];
      const all = [...answersEl.querySelectorAll("button")];
      all.forEach((button, i) => { button.disabled = true; if (i === item.correct) button.classList.add("correct"); });
      if (index === item.correct) { score += 1; feedbackEl.textContent = item.explain; }
      else { selectedButton.classList.add("wrong"); feedbackEl.textContent = `Casi… La respuesta correcta era: ${item.a[item.correct]}.`; }
      document.getElementById("scoreLabel").textContent = `Puntos: ${score}`;
      document.getElementById("progressBar").style.width = `${(questionIndex + 1) / questions.length * 100}%`;
      nextQuestionBtn.disabled = false;
    }
    nextQuestionBtn.addEventListener("click", () => {
      if (!answered) return;
      if (questionIndex < questions.length - 1) { questionIndex++; renderQuestion(); }
      else {
        questionEl.textContent = score === 4 ? "¡Sos la leyenda de Halloween! 🦇" : score >= 2 ? "¡Buen trabajo, explorador de las sombras! 👻" : "¡La noche te da otra oportunidad! 🎃";
        answersEl.innerHTML = "";
        feedbackEl.textContent = `Tu resultado final: ${score} de ${questions.length} respuestas correctas.`;
        document.getElementById("questionCount").textContent = "Desafío terminado";
        document.getElementById("progressBar").style.width = "100%";
        nextQuestionBtn.textContent = "Jugar otra vez ↻";
        nextQuestionBtn.disabled = false;
        nextQuestionBtn.onclick = () => { questionIndex = 0; score = 0; document.getElementById("scoreLabel").textContent = "Puntos: 0"; nextQuestionBtn.onclick = null; renderQuestion(); };
      }
    });
    renderQuestion();

    // Mensajes misteriosos
    const spells = [
      "Una sorpresa bonita llegará cuando menos lo esperes.",
      "Tu imaginación es más poderosa que cualquier monstruo.",
      "Hoy es una buena noche para crear algo extraordinario.",
      "No toda sombra esconde un peligro; algunas guardan historias.",
      "La valentía también consiste en hacer preguntas.",
      "El misterio más grande es el que todavía no descubriste…"
    ];
    document.getElementById("spellBtn").addEventListener("click", () => {
      const message = spells[Math.floor(Math.random() * spells.length)];
      document.getElementById("spellMessage").textContent = message;
      playTone(540, .12);
      setTimeout(() => playTone(760, .18), 120);
    });

    // Sorpresa y avisos
    const toast = document.getElementById("toast");
    let toastTimer;
    function showToast(message) {
      toast.textContent = message; toast.classList.add("show");
      clearTimeout(toastTimer); toastTimer = setTimeout(() => toast.classList.remove("show"), 2800);
    }
    document.getElementById("surpriseBtn").addEventListener("click", () => {
      const surprises = ["¡Un murciélago acaba de cruzar el cielo! 🦇", "Escuchaste un crujido detrás de vos… ¡era una rama! 🌿", "La calabaza te desea una feliz noche de Halloween. 🎃", "Un fantasma invisible te manda saludos. 👻"];
      showToast(surprises[Math.floor(Math.random() * surprises.length)]);
      playTone(300, .16);
    });

    // Ambiente sonoro generado en el navegador; solo se activa tras tocar el botón.
    let audioContext = null, ambientTimer = null, soundOn = false;
    function playTone(frequency = 180, duration = .3, volume = .035) {
      if (!soundOn && frequency !== 540 && frequency !== 760) return;
      try {
        audioContext ||= new (window.AudioContext || window.webkitAudioContext)();
        if (audioContext.state === "suspended") audioContext.resume();
        const oscillator = audioContext.createOscillator();
        const gain = audioContext.createGain();
        oscillator.type = "sine"; oscillator.frequency.setValueAtTime(frequency, audioContext.currentTime);
        gain.gain.setValueAtTime(volume, audioContext.currentTime);
        gain.gain.exponentialRampToValueAtTime(.001, audioContext.currentTime + duration);
        oscillator.connect(gain); gain.connect(audioContext.destination);
        oscillator.start(); oscillator.stop(audioContext.currentTime + duration);
      } catch (error) { /* El sitio funciona aunque el navegador no permita audio. */ }
    }
    function startAmbient() {
      soundOn = true;
      document.getElementById("soundToggle").textContent = "🔇 Apagar ambiente";
      document.getElementById("soundToggle").setAttribute("aria-pressed", "true");
      playTone(110, .7, .025);
      ambientTimer = setInterval(() => {
        if (soundOn) playTone([90, 110, 130, 160][Math.floor(Math.random() * 4)], .8, .012);
      }, 2600);
      showToast("Ambiente misterioso activado. 🔊");
    }
    function stopAmbient() {
      soundOn = false; clearInterval(ambientTimer);
      document.getElementById("soundToggle").textContent = "🔊 Activar ambiente";
      document.getElementById("soundToggle").setAttribute("aria-pressed", "false");
      showToast("Ambiente apagado. 🌙");
    }
    document.getElementById("soundToggle").addEventListener("click", () => soundOn ? stopAmbient() : startAmbient());
